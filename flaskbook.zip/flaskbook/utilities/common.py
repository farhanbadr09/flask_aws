import time
def utc_now_its():
    return int(time.time())
