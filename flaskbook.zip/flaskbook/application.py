#!/usr/bin/env python
# encoding: utf-8
from flask import Flask
from flask_mongoengine import MongoEngine
# generating seceret key
import os
SECRET_KEY = os.urandom(32)
# 
app = Flask(__name__)
app.config['SECRET_KEY'] = SECRET_KEY
app.config['MONGODB_SETTINGS'] = {
	    # 'db': 'farhan',
	    'host': 'mongodb+srv://farhan:farhan09@flaskdb.byb0q.mongodb.net/flask_user?retryWrites=true&w=majority'
	}

db = MongoEngine()

db.init_app(app)
# 
def create_app():
	# db = MongoEngine()
	from user.view import user_app
	# db.init_app(app)
	app.register_blueprint(user_app)
	return app.run(debug=True)

# if __name__ == "__main__":
#     app.run(debug=True)
if __name__ == "__main__":
	create_app()

# def create_app():
#     app = Flask(__name__)
#     from user.view import user_app
#     db.db.series
#     # app.register_blueprint(user_app)
#     return app.run()

# if __name__ == "__main__":
#     create_app()

























# from flask import Flask, Blueprint
# from flask_mongoengine import MongoEngine
# from flask_pymongo import PyMongo
# app = Flask(__name__)

# app.config["MONGO_URI"] = "mongodb+srv://farhan:<farhan09>@flaskdb.byb0q.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
# db = PyMongo(app)
# def create_app():
#     app = Flask(__name__)
#     from user.view import user_app
#     db.init_app(app)
#     app.register_blueprint(user_app)
#     return app.run()

# if __name__ == "__main__":
#     create_app()













# from flask import Flask, jsonify, request, redirect
# from flask_pymongo import PyMongo
# from pymongo import MongoClient
# client = MongoClient()
# app = Flask(__name__)
# app.config["MONGO_URI"] = "mongodb+srv://farhan:farhan09@flaskdb.byb0q.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
# mongo = PyMongo(app)
# #All the routings in our app will be mentioned here.
# @app.route('/test')
# def test():
# 	database_names = mongo.db()
# 	return database_names
# if __name__ == '__main__':app.run(debug=True)