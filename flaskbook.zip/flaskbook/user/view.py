from flask import Blueprint, render_template
from application import app, db
from flask import jsonify
from user.forms import RegisterForm
user_app = Blueprint('user_app', __name__)
@user_app.route('/')
def login():
	data = db.get_db().list_collection_names()
	return jsonify(data)
@user_app.route('/register', methods=['GET', 'POST'])
def register():
	form = RegisterForm()
	return render_template('user/register.html',form = form)
